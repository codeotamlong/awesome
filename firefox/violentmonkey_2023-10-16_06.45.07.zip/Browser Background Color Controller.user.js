// ==UserScript==
// @name           Browser Background Color Controller
// @namespace      Background Color
// @description    Change the background color in all web pages to protect your eyes. we map different original color to different new colors automatically to make it looks better than others which only replace the original color with only one color.
// @version        2.5
// @include        http*
// @include        ftp
// @exclude
// @license MIT
// @grant    GM_addStyle
// ==/UserScript==

// Threshold
var Rth = 225;
var Gth = 225;
var Bth = 225;
var color = "#FDF6E3" //New color
var renderClasses = ["nH"];


function parseRGB(RGB) {
    if (RGB == undefined) return[0, 0, 0, 0];
    var rgba = RGB.replace(/[rgba\(\)]/g, '');
    var bg = rgba.split(",");
    if (bg < 3) return[0, 0, 0, 0];
    return [parseInt(bg[0]), parseInt(bg[1]), parseInt(bg[2]), parseInt(bg[3])];
}

function adjust(color, amount) {
        return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + Math.floor(amount))).toString(16)).substr(-2));
    }

function rgbToHex(rgb) {
  function componentToHex(c) {
      var hex = parseInt(c).toString(16);
      return hex.length == 1 ? "0" + hex : hex;
  }
  rgb = rgb.replace(/[^\d,]/g, '').split(',');
  return "#" + componentToHex(rgb[0]) + componentToHex(rgb[1]) + componentToHex(rgb[2]);
}

function hexToRgb(hex) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16)
  ] : null;
}


function realBackgroundColor(elem) {
    var transparent = 'rgba(0, 0, 0, 0)';
    if (!elem) return transparent;

    var computed = getComputedStyle(elem);
    if (computed.backgroundImage !== "none") {
        return undefined;
    }

    var bg = computed.backgroundColor;
    if (bg === transparent) {
        return realBackgroundColor(elem.parentElement);
    } else {
        return bg;
    }
}



function changeElementsColor() {
    var allTags = document.querySelectorAll("*:not(style, script, meta, noscript)");
    var classes = [];
    var colors = []
    var hover = [].slice.call(document.querySelectorAll( ":hover" ));
    for (var i = 0; i < allTags.length; i++) {
        try{
            console.log(allTags[i].nodeName);
            var txtcolor = window.getComputedStyle(allTags[i], null).getPropertyValue('color').replace(/[^\d,]/g, '').split(',');
            var should_change_txt = (txtcolor[0] > 230 && txtcolor[1] > 230 && txtcolor[2] > 230);
            if ((allTags[i].style.backgroundColor == color || allTags[i].style.bgColorAlreadySet == true) && !should_change_txt) {
                continue;
            }
            allTags[i].style.bgColorAlreadySet = true;
            var rbgcolor = realBackgroundColor(allTags[i]);
            var RGB = parseRGB(rbgcolor);
            var acolor = adjust(color, Math.max(-10, (RGB[0] + RGB[1] + RGB[2]) / 3 - 255));
            var set_color_this_time = false;
            if (RGB[0] > Rth && RGB[1] > Gth && RGB[2] > Bth || allTags[i].tagName == "BODY") {
            //if (RGB[0] + RGB[1] + RGB[2] > Rth * 3 || allTags[i].tagName == "BODY") {
                allTags[i].style.backgroundColor = acolor;
                set_color_this_time = true;
                //if (allTags[i].innerText != undefined && allTags[i].innerText.startsWith("Start a new repository\n\nA"))
                //    console.log(allTags[i], allTags[i].style.backgroundColor, acolor)
                //console.log(Math.max(-10, (RGB[0] + RGB[1] + RGB[2]) / 3 - 255));
                //console.log(allTags[i].classList.map(x=>`.${x}{background-color: #FDF6E3}\n`))
                //for (var j = 0; j < allTags[i].classList.length; ++j){
                //    classes.push(`.${allTags[i].classList[j]}{background-color: ${acolor}}\n`);
                //}
                //console.log( allTags[i]);
                //if (txtcolor[0] > 230 && txtcolor[1] > 230 && txtcolor[2] > 230){
                //    allTags[i].style.color = "#073642";
                //}
            }
            var aRGB = hexToRgb(acolor);
            var margin = 12
            if ((Math.abs(RGB[0] - aRGB[0]) < margin && Math.abs(RGB[1] - aRGB[1]) < margin && Math.abs(RGB[2] - aRGB[2]) < margin || set_color_this_time) && should_change_txt){
                allTags[i].style.color = "#073642";
            }
        }catch(err) {
            console.log(err);
        }
    }
    //console.log(classes);
    //GM_addStyle(classes.join(""));
    //GM_addStyle(renderClasses.map(x=>`.${x}{background-color: ${color}}\n`).join(""));
}

function handleAutoPage() {
    var observer = new window.MutationObserver(function(mutations) {
        var currentLen = document.getElementsByTagName("*").length;
        if (mutations[0].addedNodes) {
                setTimeout(function() {
                    if(document.getElementsByTagName("*").length == currentLen){
                        //console.log(document.getElementsByTagName("*").length)
                        changeElementsColor();
                    }
                }, 50);
        }
    });
    observer.observe(document, {
        childList: true,
        subtree: true
    });
}


(function() {
    changeElementsColor();
    handleAutoPage();

})();

